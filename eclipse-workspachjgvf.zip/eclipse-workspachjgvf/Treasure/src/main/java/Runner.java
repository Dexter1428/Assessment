import java.util.*;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		Treasure gold = new Treasure();
		//gold.hideTreasure();
		
		Player p1 = new Player();
		
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		System.out.print(p1);
		
	}
}
