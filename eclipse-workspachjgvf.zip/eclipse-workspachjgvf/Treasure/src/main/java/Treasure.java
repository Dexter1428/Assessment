
public class Treasure {

}
