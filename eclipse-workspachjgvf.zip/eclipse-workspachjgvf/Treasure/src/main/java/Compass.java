import java.util.*;

public class Compass {
	
	private String input;
	private int positionX;
	private int positionY;
	
	
	public Compass(){
		
		if (getInput() == "north") {
			
			positionX + 1
			
		}
		
		//input.sc == "north"
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public int getPositionX() {
		return positionX;
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public int getPositionY() {
		return positionY;
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}
	

}
