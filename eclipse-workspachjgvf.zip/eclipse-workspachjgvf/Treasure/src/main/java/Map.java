
public class Map {
	
	int positionX;
	int positionY;
	String name;
	
	public void Treasure(String name) {
		
		this.name=name;
		this.positionX=2;
		this.positionY=2;
		
		
	}
	public void Player(String name) {
		this.name=name;
		this.positionX=0;
		this.positionY=0;
	}
	
	public void hideTreasure() {
		positionX=(int)(Math.random()*2);
		positionY=(int)(Math.random()*2);
	}
	
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return(name);
	}
	public int getPositionX() {
		return positionX;
	}
	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}
	public int getPositionY() {
		return positionY;
	}
	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
}
